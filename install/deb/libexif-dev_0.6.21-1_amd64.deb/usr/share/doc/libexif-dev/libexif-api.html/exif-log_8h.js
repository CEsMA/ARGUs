var exif_log_8h =
[
    [ "EXIF_LOG_NO_MEMORY", "exif-log_8h.html#a4221b964f5ee550f6166126b263d3b2f", null ],
    [ "ExifLog", "exif-log_8h.html#a6b225115984bb2016282923cb487f16b", null ],
    [ "ExifLogFunc", "exif-log_8h.html#a5f19ac102b6d554320d6afb32f85c3d3", null ],
    [ "ExifLogCode", "exif-log_8h.html#a36f42667fb0481f099dbc0628dae2652", [
      [ "EXIF_LOG_CODE_NONE", "exif-log_8h.html#a36f42667fb0481f099dbc0628dae2652a3b611d0d574b7838c2d5173367d96ed3", null ],
      [ "EXIF_LOG_CODE_DEBUG", "exif-log_8h.html#a36f42667fb0481f099dbc0628dae2652ae8772b1ad05481f996ae4ab831f22860", null ],
      [ "EXIF_LOG_CODE_NO_MEMORY", "exif-log_8h.html#a36f42667fb0481f099dbc0628dae2652a58e7ceb39d196fb60b18ec9713c74336", null ],
      [ "EXIF_LOG_CODE_CORRUPT_DATA", "exif-log_8h.html#a36f42667fb0481f099dbc0628dae2652a84901c6bc122ed1de41cc8fb08b6ccc8", null ]
    ] ],
    [ "exif_log", "exif-log_8h.html#a3317c341014d6ed3ea726f66116d5de0", null ],
    [ "exif_log_code_get_message", "exif-log_8h.html#afe3839462dc826b72b9b13cdc6931473", null ],
    [ "exif_log_code_get_title", "exif-log_8h.html#a31cf3057f5546ae2881d817c70ebca55", null ],
    [ "exif_log_free", "exif-log_8h.html#acd0808d6d5be73f28059797c2e2e67dc", null ],
    [ "exif_log_new", "exif-log_8h.html#a92d3525981d3d604521ca74ce05d0add", null ],
    [ "exif_log_new_mem", "exif-log_8h.html#ad6e1adde9d6188d369e3cc45b3aa7815", null ],
    [ "exif_log_ref", "exif-log_8h.html#aafd7e5d40ca73440976a3b684bfa1059", null ],
    [ "exif_log_set_func", "exif-log_8h.html#a493a369b7020265971cdaf8be9a2f6fe", null ],
    [ "exif_log_unref", "exif-log_8h.html#a7a9b738a7429197d68c80ffedac7d8fb", null ],
    [ "exif_logv", "exif-log_8h.html#af5f451d1ffd6538a88ca59798799af41", null ]
];
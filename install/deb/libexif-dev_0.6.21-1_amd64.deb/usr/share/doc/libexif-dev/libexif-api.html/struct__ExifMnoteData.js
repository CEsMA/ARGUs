var struct__ExifMnoteData =
[
    [ "log", "struct__ExifMnoteData.html#acc3a8f10ea19d9f5b91a695d0c788d1c", null ],
    [ "mem", "struct__ExifMnoteData.html#af4e3979d486789a2005b01100bc48c4b", null ],
    [ "methods", "struct__ExifMnoteData.html#a431955e099ce8f160de45644f2bddaeb", null ],
    [ "priv", "struct__ExifMnoteData.html#a2ae504353208ea00d72906607df65cd1", null ]
];
var struct__ExifMnoteDataMethods =
[
    [ "count", "struct__ExifMnoteDataMethods.html#aaad86617351c2ee737b392f94040cccb", null ],
    [ "free", "struct__ExifMnoteDataMethods.html#aa63698879f7a67e6b17c112b1bd5bad8", null ],
    [ "get_description", "struct__ExifMnoteDataMethods.html#a4ca7e0ab9aed5703a2038699e9bcc486", null ],
    [ "get_id", "struct__ExifMnoteDataMethods.html#a453d479929b42b3db130e4853ca1f0c5", null ],
    [ "get_name", "struct__ExifMnoteDataMethods.html#a478e4e150437d70bdfdb6ceb274603eb", null ],
    [ "get_title", "struct__ExifMnoteDataMethods.html#ac14c8b9a7a9a282b94fc2c7476110d25", null ],
    [ "get_value", "struct__ExifMnoteDataMethods.html#a35e308b7ffbdc5dcd6681eab820ba444", null ],
    [ "load", "struct__ExifMnoteDataMethods.html#a351860e435018eb6f20a1a80cc848058", null ],
    [ "save", "struct__ExifMnoteDataMethods.html#a885058f650d7e6dfbac29f391f1c3be1", null ],
    [ "set_byte_order", "struct__ExifMnoteDataMethods.html#a2e6037a3070fa6b0f2a66b16c5ce70ae", null ],
    [ "set_offset", "struct__ExifMnoteDataMethods.html#abb617ca9aecebc6a4bdea49aec2bc8b0", null ]
];

void generalInterfaceExamples ();


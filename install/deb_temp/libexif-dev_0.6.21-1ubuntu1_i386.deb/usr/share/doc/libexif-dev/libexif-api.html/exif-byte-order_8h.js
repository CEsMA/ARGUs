var exif_byte_order_8h =
[
    [ "ExifByteOrder", "exif-byte-order_8h.html#af966227d69ff74eea7ecd69ca645155b", [
      [ "EXIF_BYTE_ORDER_MOTOROLA", "exif-byte-order_8h.html#af966227d69ff74eea7ecd69ca645155bad71d87054b55fd62b0eed2c2c5e879b1", null ],
      [ "EXIF_BYTE_ORDER_INTEL", "exif-byte-order_8h.html#af966227d69ff74eea7ecd69ca645155ba851fef40a65a105b066115210a6b40b9", null ]
    ] ],
    [ "exif_byte_order_get_name", "exif-byte-order_8h.html#ae724c175be51c0811871df3abc8141ed", null ]
];
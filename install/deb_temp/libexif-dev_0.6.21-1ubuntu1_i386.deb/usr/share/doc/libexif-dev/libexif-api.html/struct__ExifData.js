var struct__ExifData =
[
    [ "data", "struct__ExifData.html#a6adaa7f443903d8fc2d2b232c67bf660", null ],
    [ "ifd", "struct__ExifData.html#a93efef6710d8b867b743ed0a152d5293", null ],
    [ "priv", "struct__ExifData.html#ac78f8625a4ee6fc2b2e8b281c2059869", null ],
    [ "size", "struct__ExifData.html#a83a9d29c7769854ea86dd48979f8b21b", null ]
];
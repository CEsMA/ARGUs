var struct__ExifEntry =
[
    [ "components", "struct__ExifEntry.html#a4d1cd87a5c3f43b3d14b087a44582c06", null ],
    [ "data", "struct__ExifEntry.html#a7fd255a932578e60a5fbaac47d4362d4", null ],
    [ "format", "struct__ExifEntry.html#a6129f19697eff3ab581e0a8455d9fbae", null ],
    [ "parent", "struct__ExifEntry.html#a6a4cb064a2c7d60f3fd439e2b3cab2a6", null ],
    [ "priv", "struct__ExifEntry.html#ab596479b192bc474d77a98600d4201e2", null ],
    [ "size", "struct__ExifEntry.html#afee38ed13748497cc838b3c746ff8559", null ],
    [ "tag", "struct__ExifEntry.html#aa03a4dc9fa98c8bbc447c19a4d0536e9", null ]
];